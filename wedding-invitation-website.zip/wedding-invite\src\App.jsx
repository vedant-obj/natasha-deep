// =====================================================
// App.jsx — Main application with envelope intro
// =====================================================
import { useState, useEffect, useRef } from "react";
import EnvelopeIntro from "./components/EnvelopeIntro";
import MusicButton from "./components/MusicButton";
import HeroSection from "./components/HeroSection";
import CoupleSection from "./components/CoupleSection";
import EventsSection from "./components/EventsSection";
import TimelineSection from "./components/TimelineSection";
import GallerySection from "./components/GallerySection";
import RSVPSection from "./components/RSVPSection";
import Footer from "./components/Footer";
import PasswordProtect from "./components/PasswordProtect";

export default function App() {
  const [isUnlocked, setIsUnlocked] = useState(() => {
    try {
      return sessionStorage.getItem("wedding_unlocked") === "true";
    } catch (e) {
      return false;
    }
  });
  const [showIntro, setShowIntro] = useState(true);
  const [mainVisible, setMainVisible] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const audioRef = useRef(null);

  useEffect(() => {
    if (isUnlocked) {
      audioRef.current = new Audio("music.mp3");
      audioRef.current.loop = true;
      audioRef.current.volume = 0.6;
    }
    return () => {
      if (audioRef.current) {
        audioRef.current.pause();
      }
    };
  }, [isUnlocked]);

  const handleIntroComplete = () => {
    setShowIntro(false);
    // Small delay then fade in main content
    setTimeout(() => setMainVisible(true), 100);
    if (audioRef.current) {
      audioRef.current.play()
        .then(() => setIsPlaying(true))
        .catch((err) => console.log("Audio autoplay blocked or failed:", err));
    }
  };

  if (!isUnlocked) {
    return <PasswordProtect onUnlock={() => setIsUnlocked(true)} />;
  }

  return (
    <>
      {/* Envelope intro overlay */}
      {showIntro && <EnvelopeIntro onComplete={handleIntroComplete} />}

      {/* Main wedding invitation */}
      <div
        style={{
          opacity: mainVisible ? 1 : 0,
          transform: mainVisible ? "translateY(0)" : "translateY(20px)",
          transition: "opacity 0.9s ease, transform 0.9s ease",
        }}
      >
        {/* Floating music toggle */}
        <MusicButton audioRef={audioRef} isPlaying={isPlaying} setIsPlaying={setIsPlaying} />

        {/* Sections */}
        <HeroSection />
        <CoupleSection />
        <EventsSection />
        <TimelineSection />
        <GallerySection />
        <RSVPSection />
        <Footer />
      </div>
    </>
  );
}
