// =====================================================
// TimelineSection.jsx — Wedding day timeline
// =====================================================
import { useEffect, useRef } from "react";
import { LotusDivider, FloralCorner } from "./DecorativeElements";
import { TIMELINE, COUPLE } from "../weddingData";

const TimelineItem = ({ item, index, isLast }) => {
  const isLeft = index % 2 === 0;

  return (
    <div
      className={`scroll-reveal relative flex items-start gap-0 mb-0 ${
        isLeft ? "flex-row" : "flex-row-reverse"
      } md:flex-row`}
      style={{ animationDelay: `${index * 0.12}s` }}
    >
      {/* Content card — desktop left/right, mobile always right */}
      <div
        className={`flex-1 pb-10 ${isLeft ? "pr-8 text-right" : "pl-8 text-left"} md:${isLeft ? "pr-8 text-right" : "pl-8 text-left"}`}
        style={{
          // Mobile: always left-aligned
          paddingLeft: "clamp(28px, 5vw, 48px)",
          paddingRight: "8px",
          textAlign: "left",
        }}
      >
        {/* Override for desktop */}
        <style>{`
          @media (min-width: 768px) {
            .timeline-item-${index} {
              padding-left: ${isLeft ? "0" : "clamp(28px,5vw,48px)"} !important;
              padding-right: ${isLeft ? "clamp(28px,5vw,48px)" : "0"} !important;
              text-align: ${isLeft ? "right" : "left"} !important;
            }
          }
        `}</style>
        <div className={`timeline-item-${index}`}>
          <span style={{
            display: "inline-block",
            fontFamily: "Cormorant Garamond, serif",
            fontSize: "10px",
            letterSpacing: "0.3em",
            color: "#d4a017",
            textTransform: "uppercase",
            marginBottom: "4px",
            background: "linear-gradient(135deg, #d4a017, #f5d78e, #b8860b)",
            WebkitBackgroundClip: "text",
            WebkitTextFillColor: "transparent",
            backgroundClip: "text",
          }}>
            {item.time}
          </span>
          <h3 style={{
            fontFamily: "Playfair Display, serif",
            fontStyle: "italic",
            fontSize: "clamp(16px, 3.5vw, 21px)",
            fontWeight: 400,
            color: "#0f2418",
            marginBottom: "4px",
            lineHeight: 1.2,
          }}>
            {item.title}
          </h3>
          <p style={{
            fontFamily: "EB Garamond, serif",
            fontSize: "clamp(12px, 2.8vw, 14px)",
            color: "rgba(26,58,42,0.55)",
            fontStyle: "italic",
            lineHeight: 1.5,
          }}>
            {item.desc}
          </p>
        </div>
      </div>

      {/* Center dot on the line */}
      <div
        className="absolute flex items-center justify-center"
        style={{
          left: "12px",
          top: "4px",
          zIndex: 2,
          // Desktop centering handled by CSS
        }}
      >
        <style>{`
          @media (min-width: 768px) {
            .dot-${index} {
              left: 50% !important;
              transform: translateX(-50%);
            }
          }
        `}</style>
        <div className={`dot-${index} absolute`} style={{ left: "12px", top: 0 }}>
          <div style={{
            width: "22px",
            height: "22px",
            borderRadius: "50%",
            background: "#faf3e0",
            border: "2px solid #1a3a2a",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            boxShadow: "0 0 0 3px rgba(212,160,23,0.25), 0 2px 8px rgba(26,58,42,0.15)",
          }}>
            <div style={{
              width: "8px",
              height: "8px",
              borderRadius: "50%",
              background: "linear-gradient(135deg, #d4a017, #f5d78e)",
            }} />
          </div>
        </div>
      </div>

      {/* Empty flex side for desktop layout */}
      <div className="hidden md:block flex-1" />
    </div>
  );
};

export default function TimelineSection() {
  const sectionRef = useRef(null);

  useEffect(() => {
    const els = sectionRef.current?.querySelectorAll(".scroll-reveal");
    const observer = new IntersectionObserver(
      (entries) => entries.forEach(e => e.isIntersecting && e.target.classList.add("visible")),
      { threshold: 0.1 }
    );
    els?.forEach(el => observer.observe(el));
    return () => observer.disconnect();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="timeline"
      className="relative py-20 px-4 paper-texture overflow-hidden"
    >
      <div className="max-w-3xl mx-auto">
        {/* Header */}
        <div className="text-center mb-14 scroll-reveal">
          <p style={{
            fontFamily: "Cormorant Garamond, serif",
            fontSize: "11px",
            letterSpacing: "0.35em",
            color: "rgba(26,58,42,0.45)",
            textTransform: "uppercase",
            marginBottom: "10px",
          }}>
            The Big Day
          </p>
          <h2 style={{
            fontFamily: "Playfair Display, serif",
            fontStyle: "italic",
            fontSize: "clamp(28px, 6vw, 42px)",
            fontWeight: 400,
            color: "#0f2418",
            marginBottom: "6px",
          }}>
            Wedding Day Timeline
          </h2>
          <p style={{
            fontFamily: "EB Garamond, serif",
            fontStyle: "italic",
            fontSize: "clamp(13px, 3vw, 15px)",
            color: "rgba(26,58,42,0.5)",
            marginBottom: "16px",
          }}>
            {COUPLE.weddingDate}
          </p>
          <div className="flex justify-center">
            <LotusDivider width={220} />
          </div>
        </div>

        {/* Timeline */}
        <div className="relative" style={{ paddingLeft: "32px" }}>
          {/* Vertical line */}
          <div
            className="absolute"
            style={{
              left: "20px",
              top: "12px",
              bottom: "12px",
              width: "1px",
              background: "linear-gradient(to bottom, transparent, rgba(212,160,23,0.5) 8%, rgba(212,160,23,0.5) 92%, transparent)",
            }}
          />
          {/* Desktop line override */}
          <style>{`
            @media (min-width: 768px) {
              .timeline-vline {
                left: 50% !important;
                transform: translateX(-50%);
              }
            }
          `}</style>
          <div
            className="timeline-vline absolute"
            style={{
              left: "20px",
              top: "12px",
              bottom: "12px",
              width: "1px",
              background: "linear-gradient(to bottom, transparent, rgba(212,160,23,0.5) 8%, rgba(212,160,23,0.5) 92%, transparent)",
            }}
          />

          {TIMELINE.map((item, index) => (
            <TimelineItem
              key={index}
              item={item}
              index={index}
              isLast={index === TIMELINE.length - 1}
            />
          ))}
        </div>

        {/* Closing note */}
        <div className="text-center mt-8 scroll-reveal" style={{ animationDelay: "0.6s" }}>
          <div
            className="inline-block relative px-8 py-4"
            style={{
              border: "1.5px solid rgba(212,160,23,0.3)",
              background: "rgba(255,255,255,0.25)",
            }}
          >
            <div className="absolute top-0 left-0"><FloralCorner size={24} /></div>
            <div className="absolute top-0 right-0" style={{ transform: "scaleX(-1)" }}><FloralCorner size={24} /></div>
            <div className="absolute bottom-0 left-0" style={{ transform: "scaleY(-1)" }}><FloralCorner size={24} /></div>
            <div className="absolute bottom-0 right-0" style={{ transform: "scale(-1)" }}><FloralCorner size={24} /></div>
            <p style={{
              fontFamily: "EB Garamond, serif",
              fontStyle: "italic",
              fontSize: "clamp(13px, 2.8vw, 15px)",
              color: "rgba(26,58,42,0.6)",
            }}>
              ✦ Timings may vary slightly — all are welcome throughout ✦
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
