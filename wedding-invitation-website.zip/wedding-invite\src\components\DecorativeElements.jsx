// =====================================================
// DecorativeElements.jsx — All SVG artwork for the site
// Peacock, elephant, floral corners, banana leaves, borders
// =====================================================

// ── Floral Corner (used in all card borders) ──────────────────────
export const FloralCorner = ({ size = 80, color = "#1a3a2a", goldColor = "#d4a017" }) => (
  <svg width={size} height={size} viewBox="0 0 80 80" fill="none" xmlns="http://www.w3.org/2000/svg">
    {/* Main branch */}
    <path d="M2 2 Q20 15 35 35" stroke={color} strokeWidth="1.5" fill="none"/>
    {/* Large petal cluster */}
    <ellipse cx="14" cy="8" rx="6" ry="4" fill={goldColor} opacity="0.7" transform="rotate(-30 14 8)"/>
    <ellipse cx="8" cy="14" rx="4" ry="6" fill={goldColor} opacity="0.6" transform="rotate(-60 8 14)"/>
    <ellipse cx="22" cy="5" rx="5" ry="3" fill={color} opacity="0.5" transform="rotate(-15 22 5)"/>
    <ellipse cx="5" cy="22" rx="3" ry="5" fill={color} opacity="0.5" transform="rotate(-75 5 22)"/>
    {/* Secondary flowers */}
    <circle cx="18" cy="18" r="3.5" fill={goldColor} opacity="0.8"/>
    <circle cx="18" cy="18" r="1.5" fill={color} opacity="0.9"/>
    {/* Leaf sprigs */}
    <path d="M10 30 Q15 20 25 22" stroke={color} strokeWidth="1" fill="none"/>
    <ellipse cx="17" cy="22" rx="5" ry="2.5" fill={color} opacity="0.35" transform="rotate(-20 17 22)"/>
    <path d="M30 10 Q20 15 22 25" stroke={color} strokeWidth="1" fill="none"/>
    <ellipse cx="22" cy="17" rx="2.5" ry="5" fill={color} opacity="0.35" transform="rotate(-70 22 17)"/>
    {/* Tiny florets */}
    <circle cx="32" cy="28" r="2" fill={goldColor} opacity="0.6"/>
    <circle cx="28" cy="32" r="2" fill={goldColor} opacity="0.6"/>
    <circle cx="8" cy="8" r="1.5" fill={goldColor} opacity="0.5"/>
    <circle cx="35" cy="35" r="2.5" fill={goldColor} opacity="0.4"/>
    {/* Vine lines */}
    <path d="M5 30 Q12 24 18 30 Q22 34 28 30" stroke={goldColor} strokeWidth="0.8" fill="none" opacity="0.6"/>
    <path d="M30 5 Q24 12 30 18 Q34 22 30 28" stroke={goldColor} strokeWidth="0.8" fill="none" opacity="0.6"/>
    {/* Dot accents */}
    <circle cx="25" cy="8" r="1" fill={goldColor} opacity="0.7"/>
    <circle cx="8" cy="25" r="1" fill={goldColor} opacity="0.7"/>
    <circle cx="12" cy="35" r="1.2" fill={goldColor} opacity="0.5"/>
    <circle cx="35" cy="12" r="1.2" fill={goldColor} opacity="0.5"/>
  </svg>
);

// ── Peacock (decorative, used in hero) ───────────────────────────
export const Peacock = ({ width = 120, color = "#1a3a2a", goldColor = "#d4a017" }) => (
  <svg width={width} height={width * 1.4} viewBox="0 0 120 168" fill="none" xmlns="http://www.w3.org/2000/svg">
    {/* Tail feathers — fan */}
    {[0, 30, 60, 90, 120, 150, 180, 210, 240, 270, 300, 330].map((angle, i) => {
      const rad = (angle - 90) * Math.PI / 180;
      const x2 = 60 + Math.cos(rad) * 62;
      const y2 = 90 + Math.sin(rad) * 62;
      return (
        <g key={i}>
          <line x1="60" y1="90" x2={x2} y2={y2} stroke={color} strokeWidth="0.8" opacity="0.4"/>
          <ellipse
            cx={60 + Math.cos(rad) * 55}
            cy={90 + Math.sin(rad) * 55}
            rx="7" ry="10"
            fill="none"
            stroke={goldColor}
            strokeWidth="0.8"
            opacity="0.55"
            transform={`rotate(${angle} ${60 + Math.cos(rad) * 55} ${90 + Math.sin(rad) * 55})`}
          />
          <circle
            cx={60 + Math.cos(rad) * 55}
            cy={90 + Math.sin(rad) * 55}
            r="3.5"
            fill={goldColor}
            opacity="0.5"
          />
          <circle
            cx={60 + Math.cos(rad) * 55}
            cy={90 + Math.sin(rad) * 55}
            r="1.5"
            fill={color}
            opacity="0.7"
          />
        </g>
      );
    })}
    {/* Body */}
    <ellipse cx="60" cy="120" rx="12" ry="22" fill={color} opacity="0.8"/>
    {/* Neck */}
    <path d="M55 102 Q52 85 58 72 Q60 68 62 72 Q68 85 65 102 Z" fill={color} opacity="0.85"/>
    {/* Head */}
    <circle cx="60" cy="68" r="9" fill={color} opacity="0.9"/>
    {/* Crest */}
    <line x1="58" y1="60" x2="55" y2="52" stroke={color} strokeWidth="1.2"/>
    <circle cx="55" cy="51" r="2.5" fill={goldColor} opacity="0.8"/>
    <line x1="60" y1="59" x2="60" y2="50" stroke={color} strokeWidth="1.2"/>
    <circle cx="60" cy="49" r="2.5" fill={goldColor} opacity="0.8"/>
    <line x1="62" y1="60" x2="65" y2="52" stroke={color} strokeWidth="1.2"/>
    <circle cx="65" cy="51" r="2.5" fill={goldColor} opacity="0.8"/>
    {/* Eye */}
    <circle cx="63" cy="67" r="2" fill="white"/>
    <circle cx="63.5" cy="67" r="1.2" fill={color}/>
    {/* Beak */}
    <path d="M60 74 L57 78 L63 77 Z" fill={goldColor} opacity="0.9"/>
    {/* Wing detail */}
    <path d="M48 108 Q42 100 44 118 Q46 126 55 128" stroke={goldColor} strokeWidth="1" fill="none" opacity="0.6"/>
    <path d="M72 108 Q78 100 76 118 Q74 126 65 128" stroke={goldColor} strokeWidth="1" fill="none" opacity="0.6"/>
    {/* Legs */}
    <line x1="55" y1="140" x2="52" y2="158" stroke={color} strokeWidth="1.5"/>
    <line x1="65" y1="140" x2="68" y2="158" stroke={color} strokeWidth="1.5"/>
    <line x1="52" y1="158" x2="47" y2="162" stroke={color} strokeWidth="1.2"/>
    <line x1="52" y1="158" x2="52" y2="164" stroke={color} strokeWidth="1.2"/>
    <line x1="68" y1="158" x2="73" y2="162" stroke={color} strokeWidth="1.2"/>
    <line x1="68" y1="158" x2="68" y2="164" stroke={color} strokeWidth="1.2"/>
  </svg>
);

// ── Elephant (small, decorative) ─────────────────────────────────
export const Elephant = ({ width = 100, color = "#1a3a2a", goldColor = "#d4a017" }) => (
  <svg width={width} height={width * 0.85} viewBox="0 0 100 85" fill="none" xmlns="http://www.w3.org/2000/svg">
    {/* Body */}
    <ellipse cx="52" cy="50" rx="32" ry="24" fill={color} opacity="0.85"/>
    {/* Head */}
    <ellipse cx="22" cy="42" rx="20" ry="18" fill={color} opacity="0.9"/>
    {/* Ear */}
    <ellipse cx="10" cy="38" rx="10" ry="14" fill={color} opacity="0.6"/>
    <ellipse cx="11" cy="39" rx="7" ry="10" fill={goldColor} opacity="0.25"/>
    {/* Trunk */}
    <path d="M6 48 Q2 55 4 64 Q5 68 8 70 Q10 68 10 64 Q10 56 12 52" fill={color} opacity="0.85"/>
    {/* Tusk */}
    <path d="M10 52 Q4 55 2 62" stroke={goldColor} strokeWidth="2.5" fill="none" strokeLinecap="round"/>
    {/* Eye */}
    <circle cx="16" cy="38" r="3" fill="white"/>
    <circle cx="16.5" cy="38" r="1.8" fill={color}/>
    <circle cx="17" cy="37.5" r="0.7" fill="white"/>
    {/* Decorative cloth/howdah */}
    <path d="M30 28 Q52 22 75 26 Q78 30 75 35 Q52 30 30 35 Z" fill={goldColor} opacity="0.55"/>
    <path d="M30 28 L30 35 M52 24 L52 33 M75 26 L75 35" stroke={color} strokeWidth="0.8" opacity="0.5"/>
    {/* Tassel */}
    <path d="M52 35 L50 42 M55 35 L53 42 M58 35 L56 42" stroke={goldColor} strokeWidth="0.8" opacity="0.7"/>
    {/* Forehead jewel */}
    <circle cx="20" cy="32" r="3" fill={goldColor} opacity="0.8"/>
    <circle cx="20" cy="32" r="1.5" fill={color} opacity="0.7"/>
    {/* Legs */}
    <rect x="30" y="68" width="11" height="16" rx="5" fill={color} opacity="0.8"/>
    <rect x="46" y="68" width="11" height="16" rx="5" fill={color} opacity="0.8"/>
    <rect x="62" y="68" width="11" height="16" rx="5" fill={color} opacity="0.8"/>
    <rect x="74" y="66" width="10" height="16" rx="5" fill={color} opacity="0.8"/>
    {/* Tail */}
    <path d="M84 55 Q92 50 90 60 Q89 63 86 62" stroke={color} strokeWidth="2" fill="none"/>
    <path d="M90 60 L92 64 M90 60 L88 65" stroke={color} strokeWidth="1.2"/>
    {/* Ankle bangles */}
    <path d="M30 78 Q40 76 41 78 Q40 80 30 80 Z" fill={goldColor} opacity="0.5"/>
    <path d="M62 78 Q72 76 73 78 Q72 80 62 80 Z" fill={goldColor} opacity="0.5"/>
  </svg>
);

// ── Banana Leaf (side decoration) ────────────────────────────────
export const BananaLeaf = ({ width = 60, color = "#1a3a2a", flipped = false }) => (
  <svg
    width={width}
    height={width * 2.5}
    viewBox="0 0 60 150"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    style={{ transform: flipped ? 'scaleX(-1)' : 'none' }}
  >
    {/* Main leaf */}
    <path d="M30 150 Q10 120 5 80 Q2 50 15 20 Q22 8 30 5 Q38 8 45 20 Q58 50 55 80 Q50 120 30 150 Z"
      fill={color} opacity="0.18"/>
    {/* Midrib */}
    <line x1="30" y1="150" x2="30" y2="5" stroke={color} strokeWidth="1.5" opacity="0.5"/>
    {/* Veins left */}
    {[20, 35, 50, 65, 80, 95, 110, 125].map((y, i) => (
      <line key={i} x1="30" y1={y} x2={30 - 18 + i} y2={y + 8} stroke={color} strokeWidth="0.7" opacity="0.3"/>
    ))}
    {/* Veins right */}
    {[20, 35, 50, 65, 80, 95, 110, 125].map((y, i) => (
      <line key={i} x1="30" y1={y} x2={30 + 18 - i} y2={y + 8} stroke={color} strokeWidth="0.7" opacity="0.3"/>
    ))}
  </svg>
);

// ── Lotus Divider ─────────────────────────────────────────────────
export const LotusDivider = ({ width = 200, color = "#1a3a2a", goldColor = "#d4a017" }) => (
  <svg width={width} height="40" viewBox="0 0 200 40" fill="none" xmlns="http://www.w3.org/2000/svg">
    {/* Lines */}
    <line x1="0" y1="20" x2="75" y2="20" stroke={goldColor} strokeWidth="0.8" opacity="0.6"/>
    <line x1="125" y1="20" x2="200" y2="20" stroke={goldColor} strokeWidth="0.8" opacity="0.6"/>
    {/* Diamond accent */}
    <polygon points="60,20 65,14 70,20 65,26" fill={goldColor} opacity="0.4"/>
    <polygon points="130,20 135,14 140,20 135,26" fill={goldColor} opacity="0.4"/>
    {/* Lotus */}
    <ellipse cx="100" cy="22" rx="5" ry="8" fill={goldColor} opacity="0.6"/>
    <ellipse cx="92" cy="23" rx="4" ry="7" fill={goldColor} opacity="0.45" transform="rotate(-20 92 23)"/>
    <ellipse cx="108" cy="23" rx="4" ry="7" fill={goldColor} opacity="0.45" transform="rotate(20 108 23)"/>
    <ellipse cx="86" cy="25" rx="3.5" ry="6" fill={color} opacity="0.3" transform="rotate(-35 86 25)"/>
    <ellipse cx="114" cy="25" rx="3.5" ry="6" fill={color} opacity="0.3" transform="rotate(35 114 25)"/>
    {/* Center */}
    <circle cx="100" cy="20" r="3.5" fill={goldColor} opacity="0.8"/>
    <circle cx="100" cy="20" r="1.8" fill={color} opacity="0.7"/>
    {/* Water ripples */}
    <path d="M85 32 Q100 28 115 32" stroke={goldColor} strokeWidth="0.7" fill="none" opacity="0.4"/>
    <path d="M88 35 Q100 32 112 35" stroke={goldColor} strokeWidth="0.5" fill="none" opacity="0.3"/>
    {/* Dot accents */}
    <circle cx="80" cy="20" r="1.5" fill={goldColor} opacity="0.5"/>
    <circle cx="120" cy="20" r="1.5" fill={goldColor} opacity="0.5"/>
    <circle cx="50" cy="20" r="1.2" fill={goldColor} opacity="0.4"/>
    <circle cx="150" cy="20" r="1.2" fill={goldColor} opacity="0.4"/>
  </svg>
);

// ── Mandala circle ────────────────────────────────────────────────
export const Mandala = ({ size = 200, color = "#1a3a2a", goldColor = "#d4a017" }) => {
  const cx = size / 2, cy = size / 2;
  const r = size * 0.42;
  const petals = 16;
  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} fill="none" xmlns="http://www.w3.org/2000/svg">
      {/* Outer ring */}
      <circle cx={cx} cy={cy} r={r} stroke={goldColor} strokeWidth="0.8" opacity="0.4"/>
      <circle cx={cx} cy={cy} r={r * 0.85} stroke={color} strokeWidth="0.5" opacity="0.3"/>
      <circle cx={cx} cy={cy} r={r * 0.65} stroke={goldColor} strokeWidth="0.8" opacity="0.35"/>
      {/* Petals */}
      {Array.from({ length: petals }).map((_, i) => {
        const angle = (i * 360 / petals) * Math.PI / 180;
        const px = cx + Math.cos(angle) * r * 0.75;
        const py = cy + Math.sin(angle) * r * 0.75;
        return (
          <ellipse
            key={i}
            cx={px} cy={py}
            rx={size * 0.04} ry={size * 0.09}
            fill={i % 2 === 0 ? goldColor : color}
            opacity={i % 2 === 0 ? 0.35 : 0.2}
            transform={`rotate(${i * 360 / petals + 90} ${px} ${py})`}
          />
        );
      })}
      {/* Inner petals */}
      {Array.from({ length: 8 }).map((_, i) => {
        const angle = (i * 45) * Math.PI / 180;
        const px = cx + Math.cos(angle) * r * 0.4;
        const py = cy + Math.sin(angle) * r * 0.4;
        return (
          <ellipse
            key={i}
            cx={px} cy={py}
            rx={size * 0.035} ry={size * 0.07}
            fill={goldColor}
            opacity="0.4"
            transform={`rotate(${i * 45 + 90} ${px} ${py})`}
          />
        );
      })}
      {/* Center */}
      <circle cx={cx} cy={cy} r={r * 0.15} fill={goldColor} opacity="0.3"/>
      <circle cx={cx} cy={cy} r={r * 0.08} fill={goldColor} opacity="0.5"/>
      <circle cx={cx} cy={cy} r={r * 0.04} fill={color} opacity="0.6"/>
      {/* Spoke lines */}
      {Array.from({ length: 8 }).map((_, i) => {
        const angle = (i * 45) * Math.PI / 180;
        return (
          <line
            key={i}
            x1={cx} y1={cy}
            x2={cx + Math.cos(angle) * r * 0.9}
            y2={cy + Math.sin(angle) * r * 0.9}
            stroke={goldColor}
            strokeWidth="0.5"
            opacity="0.2"
          />
        );
      })}
    </svg>
  );
};

// ── Om symbol ─────────────────────────────────────────────────────
export const OmSymbol = ({ size = 48, color = "#d4a017" }) => (
  <svg width={size} height={size} viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
    <text
      x="50%"
      y="55%"
      dominantBaseline="middle"
      textAnchor="middle"
      fontSize={size * 0.72}
      fill={color}
      fontFamily="Noto Serif Devanagari, serif"
      opacity="0.75"
    >
      ॐ
    </text>
  </svg>
);

// ── Border frame (full card border with corners) ──────────────────
export const BorderFrame = ({ children, className = "" }) => (
  <div className={`relative ${className}`}>
    <div className="corner-tl"><FloralCorner size={72} /></div>
    <div className="corner-tr"><FloralCorner size={72} /></div>
    <div className="corner-bl"><FloralCorner size={72} /></div>
    <div className="corner-br"><FloralCorner size={72} /></div>
    {children}
  </div>
);
