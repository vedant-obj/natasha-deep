// =====================================================
// WEDDING DETAILS — EDIT ALL VALUES HERE
// =====================================================

export const COUPLE = {
  // ✏️ EDIT: Groom's name
  groom: "Arjun",
  groomFull: "Arjun Sharma",
  groomFamilyDesc: "Son of Mr. Rakesh Sharma & Mrs. Sunita Sharma",

  // ✏️ EDIT: Bride's name
  bride: "Priya",
  brideFull: "Priya Mehta",
  brideFamilyDesc: "Daughter of Mr. Vikram Mehta & Mrs. Kavita Mehta",

  // ✏️ EDIT: Wedding date in readable format
  weddingDate: "Saturday, 14th February 2026",

  // ✏️ EDIT: Short tagline
  tagline: "Two hearts, one journey",

  // ✏️ EDIT: Sanskrit/Hindi blessing line
  blessing: "विवाह",

  // ✏️ EDIT: City/location
  city: "Mumbai, India",
};

export const EVENTS = [
  {
    id: "haldi",
    title: "Haldi",
    // ✏️ EDIT: emoji or icon key
    icon: "🌼",
    date: "Wednesday, 11th February 2026",
    time: "10:00 AM – 1:00 PM",
    venue: "Mehta Residence",
    address: "14, Palm Grove Lane, Juhu, Mumbai",
    description: "A joyful morning ceremony where turmeric paste is applied to the bride and groom, bringing blessings of radiance and prosperity.",
    color: "from-yellow-50 to-amber-50",
    accentColor: "#d4a017",
    // ✏️ EDIT: Replace with actual Google Maps link
    mapsLink: "https://maps.google.com/?q=Juhu+Mumbai",
  },
  {
    id: "mehendi",
    title: "Mehendi",
    icon: "🌿",
    date: "Wednesday, 11th February 2026",
    time: "5:00 PM – 10:00 PM",
    venue: "The Grand Pavilion",
    address: "Bandra Kurla Complex, Mumbai 400051",
    description: "An enchanting evening of intricate mehndi artistry, music, and celebration as the bride is adorned with beautiful henna designs.",
    color: "from-green-50 to-emerald-50",
    accentColor: "#1a3a2a",
    // ✏️ EDIT: Replace with actual Google Maps link
    mapsLink: "https://maps.google.com/?q=Bandra+Kurla+Complex+Mumbai",
  },
  {
    id: "sangeet",
    title: "Sangeet",
    icon: "🎶",
    date: "Thursday, 12th February 2026",
    time: "7:00 PM – 11:30 PM",
    venue: "The Royal Ballroom",
    address: "Taj Lands End, Bandra West, Mumbai",
    description: "A spectacular evening of song, dance, and merriment where both families come together to celebrate the union with performances.",
    color: "from-rose-50 to-pink-50",
    accentColor: "#8b1a2a",
    // ✏️ EDIT: Replace with actual Google Maps link
    mapsLink: "https://maps.google.com/?q=Taj+Lands+End+Bandra+Mumbai",
  },
  {
    id: "wedding",
    title: "Wedding Ceremony",
    icon: "🕉️",
    date: "Saturday, 14th February 2026",
    time: "10:30 AM – 2:00 PM",
    venue: "Shri Ganesh Mandir Grounds",
    address: "Chowpatty, Mumbai 400007",
    description: "The sacred Vedic ceremony uniting Arjun and Priya in the holy bonds of matrimony, witnessed by family, friends, and the divine.",
    color: "from-amber-50 to-orange-50",
    accentColor: "#d4a017",
    // ✏️ EDIT: Replace with actual Google Maps link
    mapsLink: "https://maps.google.com/?q=Chowpatty+Mumbai",
  },
  {
    id: "reception",
    title: "Reception",
    icon: "✨",
    date: "Saturday, 14th February 2026",
    time: "7:30 PM onwards",
    venue: "The Grand Palace",
    address: "Nariman Point, Mumbai 400021",
    description: "An elegant evening reception to celebrate the newlyweds. Join us for an evening of fine dining, music, and cherished memories.",
    color: "from-purple-50 to-indigo-50",
    accentColor: "#2a1a4a",
    // ✏️ EDIT: Replace with actual Google Maps link
    mapsLink: "https://maps.google.com/?q=Nariman+Point+Mumbai",
  },
];

export const TIMELINE = [
  { time: "10:00 AM", title: "Baraat Arrival", desc: "The groom arrives in a grand procession" },
  { time: "10:30 AM", title: "Jaimala Ceremony", desc: "Exchange of flower garlands" },
  { time: "11:00 AM", title: "Sacred Rituals", desc: "Vedic ceremonies begin" },
  { time: "12:30 PM", title: "Saat Pheras", desc: "Seven sacred vows around the holy fire" },
  { time: "1:30 PM", title: "Vidaai", desc: "The bride takes leave of her family" },
  { time: "7:30 PM", title: "Reception", desc: "Grand celebration with family & friends" },
];

// ✏️ EDIT: Your contact details
export const CONTACT = {
  phone: "+91 98765 43210",
  email: "arjunandpriya2026@gmail.com",
};

// ✏️ PASSWORD CONFIGURATION (Case-Insensitive)
export const PASSWORDS = {
  groom: "arjun", // Password 1
  bride: "priya", // Password 2
};

// ✏️ FIREBASE CONFIGURATION (For RSVP database lookup and storage)
export const FIREBASE_CONFIG = {
  apiKey:        "AIzaSyCJhrIXLt28UZ58y5PudFqZ3j5W6LrIT9g",
  authDomain:    "natashawedding-af3a4.firebaseapp.com",
  projectId:     "natashawedding-af3a4",
  storageBucket: "natashawedding-af3a4.firebasestorage.app",
};

// ✏️ EMAILJS CONFIGURATION (For RSVP email notifications)
export const EMAILJS_CONFIG = {
  pubKey:     "PASTE_YOUR_EMAILJS_PUBLIC_KEY",
  serviceId:  "PASTE_YOUR_SERVICE_ID",
  confirmTpl: "PASTE_YOUR_CONFIRMATION_TEMPLATE_ID",
};


