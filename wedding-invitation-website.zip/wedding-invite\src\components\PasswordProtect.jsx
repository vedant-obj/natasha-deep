// =====================================================
// PasswordProtect.jsx — Password protection gate screen
// =====================================================
import { useState } from "react";
import { FloralCorner, OmSymbol, Mandala } from "./DecorativeElements";
import { COUPLE, PASSWORDS } from "../weddingData";

export default function PasswordProtect({ onUnlock }) {
  const [passcode, setPasscode] = useState("");
  const [error, setError] = useState("");
  const [shake, setShake] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    setError("");

    const input = passcode.trim().toLowerCase();
    const groomPass = (PASSWORDS?.groom || "arjun").toLowerCase();
    const bridePass = (PASSWORDS?.bride || "priya").toLowerCase();

    if (input === groomPass || input === bridePass) {
      try {
        sessionStorage.setItem("wedding_unlocked", "true");
      } catch (err) {}
      onUnlock();
    } else {
      setError("Incorrect passcode. Please try again.");
      setShake(true);
      setTimeout(() => setShake(false), 500);
    }
  };

  return (
    <div
      className="fixed inset-0 z-[2000] flex flex-col items-center justify-center p-4 overflow-hidden"
      style={{
        background: "radial-gradient(ellipse at center, #0f2418 0%, #091a10 100%)",
      }}
    >
      {/* Floating particles */}
      {[...Array(8)].map((_, i) => (
        <div
          key={i}
          className="absolute rounded-full pointer-events-none"
          style={{
            width: `${3 + (i % 3) * 2}px`,
            height: `${3 + (i % 3) * 2}px`,
            background: "rgba(212,160,23,0.3)",
            left: `${10 + i * 11}%`,
            top: `${15 + (i % 4) * 20}%`,
            animation: `float ${6 + i * 0.5}s ease-in-out infinite`,
            animationDelay: `${i * 0.3}s`,
          }}
        />
      ))}

      {/* Floating mandala background */}
      <div className="absolute inset-0 flex items-center justify-center opacity-5 pointer-events-none">
        <Mandala size={400} color="#faf3e0" goldColor="#d4a017" />
      </div>

      {/* Card container */}
      <div
        className={`invitation-border w-full max-w-[420px] rounded-[3px] p-6 sm:p-10 relative text-center paper-texture transition-all duration-300 ${
          shake ? "animate-shake" : ""
        }`}
        style={{
          boxShadow: "0 20px 60px rgba(0,0,0,0.5), inset 0 0 0 4px #faf3e0, inset 0 0 0 6px rgba(212, 160, 23, 0.5), inset 0 0 0 8px #faf3e0",
        }}
      >
        {/* Floral Corners */}
        <div className="corner-tl"><FloralCorner size={60} /></div>
        <div className="corner-tr"><FloralCorner size={60} /></div>
        <div className="corner-bl"><FloralCorner size={60} /></div>
        <div className="corner-br"><FloralCorner size={60} /></div>

        <div className="invitation-border-inner rounded-[2px] p-4 sm:p-6">
          <div className="flex justify-center mb-2">
            <OmSymbol size={36} color="#1a3a2a" />
          </div>
          <p
            className="font-serif text-[11px] uppercase tracking-[0.15em] text-emerald-800/60 mb-4"
            style={{ fontFamily: "'Noto Serif Devanagari', serif" }}
          >
            ॥ श्री गणेशाय नमः ॥
          </p>

          <h2 className="font-display italic text-3xl sm:text-4xl font-normal text-[#1a3a2a] mb-2 leading-tight">
            {COUPLE.groom} & {COUPLE.bride}
          </h2>
          <p className="font-serif text-[10px] sm:text-[11px] uppercase tracking-[0.25em] text-emerald-800/50 mb-6">
            Wedding Invitation
          </p>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label
                htmlFor="guest-passcode"
                className="block font-serif text-[11px] uppercase tracking-[0.2em] text-[#1a3a2a]/70 mb-2"
              >
                Enter Guest Passcode
              </label>
              <input
                id="guest-passcode"
                type="password"
                value={passcode}
                onChange={(e) => setPasscode(e.target.value)}
                placeholder="Passcode..."
                className="w-full bg-white/80 border border-emerald-950/30 rounded-[3px] px-4 py-2.5 font-serif text-base text-emerald-950 outline-none text-center transition-all duration-300 focus:border-[#d4a017] focus:ring-1 focus:ring-[#d4a017]/20"
              />
              {error && (
                <p className="font-serif text-xs text-[#8b1a2a] mt-2 italic">
                  {error}
                </p>
              )}
            </div>

            <button
              type="submit"
              className="w-full font-serif text-[11px] sm:text-[12px] uppercase tracking-[0.25em] text-[#faf3e0] bg-[#1a3a2a] border border-[#d4a017]/40 py-3.5 rounded-[2px] cursor-pointer transition-all duration-300 hover:bg-[#0f2418] hover:border-[#d4a017]"
            >
              Unlock Invitation
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
