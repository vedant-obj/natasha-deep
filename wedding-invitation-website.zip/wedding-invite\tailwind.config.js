/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        cream: {
          50: '#fdfaf4',
          100: '#faf3e0',
          200: '#f5e6c8',
          300: '#eed5a0',
        },
        forest: {
          800: '#1a3a2a',
          900: '#0f2418',
          950: '#091a10',
        },
        gold: {
          300: '#f5d78e',
          400: '#e8c05a',
          500: '#d4a017',
          600: '#b8860b',
        }
      },
      fontFamily: {
        serif: ['Cormorant Garamond', 'Georgia', 'serif'],
        display: ['Playfair Display', 'Georgia', 'serif'],
        body: ['EB Garamond', 'Georgia', 'serif'],
        devanagari: ['Noto Serif Devanagari', 'serif'],
      },
      animation: {
        'envelope-open': 'envelopeOpen 1.5s ease-in-out forwards',
        'fade-up': 'fadeUp 0.8s ease-out forwards',
        'shimmer': 'shimmer 3s ease-in-out infinite',
        'float': 'float 6s ease-in-out infinite',
        'float-slow': 'floatSlow 8s ease-in-out infinite',
        'gold-glow': 'goldGlow 3s ease-in-out infinite',
      },
      keyframes: {
        envelopeOpen: {
          '0%': { transform: 'rotateX(0deg)', opacity: '1' },
          '100%': { transform: 'rotateX(-180deg)', opacity: '0' },
        },
        fadeUp: {
          '0%': { opacity: '0', transform: 'translateY(30px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        shimmer: {
          '0%, 100%': { backgroundPosition: '0% 50%' },
          '50%': { backgroundPosition: '100% 50%' },
        },
        float: {
          '0%, 100%': { transform: 'translateY(0px) rotate(0deg)' },
          '33%': { transform: 'translateY(-12px) rotate(2deg)' },
          '66%': { transform: 'translateY(-6px) rotate(-1deg)' },
        },
        floatSlow: {
          '0%, 100%': { transform: 'translateY(0px) rotate(-2deg)' },
          '50%': { transform: 'translateY(-18px) rotate(2deg)' },
        },
        goldGlow: {
          '0%, 100%': { filter: 'brightness(1) drop-shadow(0 0 4px rgba(212,160,23,0.3))' },
          '50%': { filter: 'brightness(1.15) drop-shadow(0 0 10px rgba(212,160,23,0.6))' },
        },
      },
    },
  },
  plugins: [],
}
