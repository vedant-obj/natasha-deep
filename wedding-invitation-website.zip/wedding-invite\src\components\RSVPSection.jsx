import { useState, useEffect, useRef } from "react";
import { initializeApp, getApps } from "firebase/app";
import { getFirestore, collection, query, where, getDocs, doc, updateDoc, addDoc, serverTimestamp } from "firebase/firestore";
import emailjs from "@emailjs/browser";
import { FloralCorner, LotusDivider, OmSymbol, BananaLeaf } from "./DecorativeElements";
import { COUPLE, EVENTS, FIREBASE_CONFIG, EMAILJS_CONFIG } from "../weddingData";

export default function RSVPSection() {
  const [db, setDb] = useState(null);
  const [step, setStep] = useState("lookup"); // lookup, invite, details, confirmed
  const [lookupCode, setLookupCode] = useState("");
  const [showNameInput, setShowNameInput] = useState(false);
  const [guestName, setGuestName] = useState("");
  const [guest, setGuest] = useState(null);
  
  const [rsvp, setRsvp] = useState("yes");
  const [headcount, setHeadcount] = useState(1);
  const [attendingEvents, setAttendingEvents] = useState(new Set());
  const [photoBase64, setPhotoBase64] = useState(null);
  const [photoPreview, setPhotoPreview] = useState(null);
  const [email, setEmail] = useState("");
  
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState("");
  
  const sectionRef = useRef(null);

  // Initialize Firebase Firestore
  useEffect(() => {
    try {
      const existing = getApps().find(a => a.name === "wedding-rsvp-react");
      const app = existing || initializeApp(FIREBASE_CONFIG, "wedding-rsvp-react");
      setDb(getFirestore(app));
    } catch (e) {
      console.error("Firebase init error:", e);
    }
  }, []);

  // Intersection observer for scroll animation
  useEffect(() => {
    const els = sectionRef.current?.querySelectorAll(".scroll-reveal");
    const observer = new IntersectionObserver(
      (entries) => entries.forEach(e => e.isIntersecting && e.target.classList.add("visible")),
      { threshold: 0.1 }
    );
    els?.forEach(el => observer.observe(el));
    return () => observer.disconnect();
  }, []);

  // Auto lookup if session passcode exists
  useEffect(() => {
    if (!db) return;
    const saved = sessionStorage.getItem("wedding_passcode");
    if (saved) {
      setLookupCode(saved.toUpperCase());
      performLookup(saved.toUpperCase());
    }
  }, [db]);

  const performLookup = async (codeToLookup) => {
    const code = (codeToLookup || lookupCode).trim().toUpperCase();
    if (!code) { setError("Please enter your invitation code."); return; }

    setError("");
    setLoading(true);

    // Passcode bypass check (for arjun / priya)
    if (code === "ARJUN" || code === "PRIYA") {
      setLoading(false);
      if (!showNameInput && !guestName) {
        setShowNameInput(true);
        return;
      }
      if (!guestName.trim()) {
        setError("Please enter your name to personalize your invitation.");
        return;
      }
      
      const allowedEvents = code === "ARJUN"
        ? EVENTS.map(e => e.id)
        : ["wedding"]; // priya is wedding only
      
      const pwdGuest = {
        id: "pwd-login",
        name: guestName.trim(),
        events: allowedEvents,
        rsvp: "pending"
      };
      
      setGuest(pwdGuest);
      setAttendingEvents(new Set(allowedEvents));
      setHeadcount(1);
      setEmail("");
      setStep("invite");
      return;
    }

    try {
      const snap = await getDocs(query(collection(db, "guests"), where("code", "==", code)));
      setLoading(false);
      if (snap.empty) {
        setError("We couldn't find that code. Please check and try again.");
        return;
      }
      const d = snap.docs[0];
      const data = { id: d.id, ...d.data() };
      setGuest(data);
      setAttendingEvents(new Set(data.events || []));
      setHeadcount(data.headcount || 1);
      setEmail(data.contact || "");
      if (data.photoBase64) {
        setPhotoBase64(data.photoBase64);
        setPhotoPreview(data.photoBase64);
      }
      setStep("invite");
      
      if (data.rsvp === "yes" || data.rsvp === "no") {
        setStep("confirmed");
        setRsvp(data.rsvp);
      }
    } catch (e) {
      setLoading(false);
      setError("Error connecting: " + e.message);
    }
  };

  const handlePhotoChange = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    if (file.size > 20 * 1024 * 1024) {
      alert("Please choose a photo under 20MB.");
      return;
    }

    const reader = new FileReader();
    reader.onload = (ev) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement("canvas");
        const MAX_SIZE = 1200;
        const ratio = Math.min(MAX_SIZE / img.width, MAX_SIZE / img.height, 1);
        canvas.width = Math.round(img.width * ratio);
        canvas.height = Math.round(img.height * ratio);
        const ctx = canvas.getContext("2d");
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        const compressed = canvas.toDataURL("image/jpeg", 0.80);
        setPhotoBase64(compressed);
        setPhotoPreview(compressed);
      };
      img.src = ev.target.result;
    };
    reader.readAsDataURL(file);
  };

  const toggleEventAttendance = (eventId) => {
    setAttendingEvents(prev => {
      const next = new Set(prev);
      if (next.has(eventId)) {
        next.delete(eventId);
      } else {
        next.add(eventId);
      }
      return next;
    });
  };

  const handleSubmit = async (answer) => {
    if (!email.trim() || !email.includes("@")) {
      setSubmitError("Please enter a valid email address so we can send your confirmation.");
      return;
    }

    setSubmitting(true);
    setSubmitError("");

    try {
      const finalEvents = answer === "yes" ? [...attendingEvents] : [];
      const finalCount = answer === "yes" ? headcount : 0;

      if (guest.id === "pwd-login") {
        const prefix = guestName.replace(/\s+/g, '').toUpperCase().slice(0, 4).padEnd(4, 'X');
        const suffix = Math.random().toString(36).substring(2, 5).toUpperCase();
        const generatedCode = prefix + suffix;

        await addDoc(collection(db, "guests"), {
          name: guestName,
          code: generatedCode,
          events: guest.events,
          rsvp: answer,
          headcount: finalCount,
          eventsAttending: finalEvents,
          photoBase64: photoBase64 || null,
          photoUploadedAt: photoBase64 ? serverTimestamp() : null,
          rsvpAt: serverTimestamp(),
          createdAt: serverTimestamp(),
          contact: email.trim(),
        });
      } else {
        await updateDoc(doc(db, "guests", guest.id), {
          rsvp: answer,
          headcount: finalCount,
          eventsAttending: finalEvents,
          photoBase64: photoBase64 || null,
          photoUploadedAt: photoBase64 ? serverTimestamp() : null,
          rsvpAt: serverTimestamp(),
          contact: email.trim(),
        });
      }

      setRsvp(answer);
      setStep("confirmed");
      setSubmitting(false);

      if (answer === "yes" || (answer === "no" && guest.contact)) {
        sendConfirmationEmail(answer, finalEvents, finalCount);
      }
    } catch (e) {
      setSubmitting(false);
      setSubmitError("Could not save your RSVP: " + e.message);
    }
  };

  const sendConfirmationEmail = async (answer, finalEvents, finalCount) => {
    try {
      if (!EMAILJS_CONFIG.pubKey || !EMAILJS_CONFIG.serviceId || !EMAILJS_CONFIG.confirmTpl) return;
      emailjs.init({ publicKey: EMAILJS_CONFIG.pubKey });
      
      const eventNames = finalEvents.map(id => {
        const ev = EVENTS.find(e => e.id === id);
        return ev ? ev.title : id;
      }).join(", ");

      const templateParams = {
        to_name: guest.id === "pwd-login" ? guestName : guest.name,
        to_email: email.trim(),
        reply_to: email.trim(),
        rsvp_status: answer === "yes" ? "Attending" : "Not attending",
        events_attending: answer === "yes" ? eventNames : "—",
        headcount: finalCount,
      };

      await emailjs.send(EMAILJS_CONFIG.serviceId, EMAILJS_CONFIG.confirmTpl, templateParams);
    } catch (e) {
      console.error("Confirmation email failed:", e);
    }
  };

  return (
    <section
      ref={sectionRef}
      id="rsvp"
      className="relative py-20 px-4 paper-texture overflow-hidden"
    >
      <div className="absolute left-0 top-1/3 opacity-12 pointer-events-none hidden xl:block animate-float" style={{ animationDelay: "0.5s" }}>
        <BananaLeaf width={60} />
      </div>
      <div className="absolute right-0 bottom-1/3 opacity-12 pointer-events-none hidden xl:block animate-float-slow" style={{ animationDelay: "1.5s" }}>
        <BananaLeaf width={60} flipped />
      </div>

      <div className="max-w-xl mx-auto">
        {/* Header */}
        <div className="text-center mb-10 scroll-reveal">
          <p style={{
            fontFamily: "Cormorant Garamond, serif",
            fontSize: "11px",
            letterSpacing: "0.35em",
            color: "rgba(26,58,42,0.45)",
            textTransform: "uppercase",
            marginBottom: "10px",
          }}>
            Kindly respond by 1st February 2026
          </p>
          <h2 style={{
            fontFamily: "Playfair Display, serif",
            fontStyle: "italic",
            fontSize: "clamp(28px, 6vw, 42px)",
            fontWeight: 400,
            color: "#0f2418",
            marginBottom: "16px",
          }}>
            RSVP
          </h2>
          <div className="flex justify-center">
            <LotusDivider width={220} />
          </div>
        </div>

        {/* Card insert */}
        <div className="event-card-insert scroll-reveal relative max-w-[540px] mx-auto bg-[#faf3e0] border-2 border-[#1a3a2a] rounded-[3px] shadow-[inset_0_0_0_3px_#faf3e0,inset_0_0_0_4.5px_rgba(212,160,23,0.42),inset_0_0_0_6px_#faf3e0,0_12px_44px_rgba(26,58,42,0.13)]">
          <div style={{ height: "6px", background: "linear-gradient(90deg, transparent, rgba(212,160,23,0.5), transparent)" }} />
          
          <div className="relative p-7">
            <div className="absolute top-0 left-0"><FloralCorner size={44} /></div>
            <div className="absolute top-0 right-0" style={{ transform: "scaleX(-1)" }}><FloralCorner size={44} /></div>
            <div className="absolute bottom-0 left-0" style={{ transform: "scaleY(-1)" }}><FloralCorner size={44} /></div>
            <div className="absolute bottom-0 right-0" style={{ transform: "scale(-1)" }}><FloralCorner size={44} /></div>

            {/* STEP 1: Lookup */}
            {step === "lookup" && (
              <div className="text-center py-4">
                <OmSymbol size={32} color="#d4a017" />
                <p className="font-playfair italic text-[clamp(17px,4vw,24px)] text-[#0f2418] mt-2 mb-2">Confirm Your RSVP</p>
                <p className="font-eb italic text-[clamp(13px,3vw,16px)] text-emerald-900/60 leading-relaxed mb-6 max-w-[400px] mx-auto">
                  Please enter your invitation code to access your personalized RSVP portal.
                </p>
                <div className="max-w-[320px] mx-auto flex flex-col gap-3">
                  {!showNameInput ? (
                    <input
                      type="text"
                      className="w-full bg-white/70 border border-emerald-950/30 rounded-[3px] p-3 text-center tracking-widest font-mono uppercase focus:border-[#d4a017] outline-none"
                      placeholder="ENTER CODE..."
                      value={lookupCode}
                      onChange={(e) => setLookupCode(e.target.value)}
                      onKeyDown={(e) => e.key === "Enter" && performLookup()}
                    />
                  ) : (
                    <div className="flex flex-col gap-2">
                      <label className="font-cormorant text-[11px] tracking-[0.25em] text-emerald-900/60 uppercase">Enter Guest Name</label>
                      <input
                        type="text"
                        className="w-full bg-white/70 border border-emerald-950/30 rounded-[3px] p-3 text-center focus:border-[#d4a017] outline-none"
                        placeholder="e.g. Rahul Sharma"
                        value={guestName}
                        onChange={(e) => setGuestName(e.target.value)}
                        onKeyDown={(e) => e.key === "Enter" && performLookup()}
                      />
                    </div>
                  )}

                  <button
                    onClick={() => performLookup()}
                    className="w-full font-cormorant text-xs tracking-[0.3em] uppercase text-[#faf3e0] bg-[#1a3a2a] border border-[#d4a017]/40 p-3 rounded-[2px] hover:bg-[#0f2418] hover:border-[#d4a017] transition-all"
                  >
                    View My Invite
                  </button>

                  {loading && (
                    <p className="font-eb italic text-xs text-emerald-900/60 mt-2">
                      Looking up your invitation...
                    </p>
                  )}
                  {error && (
                    <p className="font-eb italic text-xs text-red-700 mt-2">
                      {error}
                    </p>
                  )}
                </div>
              </div>
            )}

            {/* STEP 2: Invite Screen */}
            {step === "invite" && guest && (
              <div className="text-center">
                <p className="font-cormorant text-[10px] tracking-[0.3em] uppercase text-[#d4a017] mb-2">✦ You are cordially invited ✦</p>
                <p className="font-eb italic text-sm text-emerald-900/60 font-semibold">Warmly welcoming</p>
                <h3 className="font-playfair italic text-3xl text-[#1a3a2a] leading-normal mb-3">{guest.name}</h3>
                <p className="font-eb italic text-sm text-emerald-900/50 leading-relaxed mb-6 max-w-[440px] mx-auto">
                  We joyfully request the pleasure of your company as we celebrate love, togetherness, and new beginnings.
                </p>

                {/* Events list */}
                <div className="text-left max-w-[440px] mx-auto mb-6">
                  <p className="font-cormorant text-[10px] tracking-[0.2em] uppercase text-emerald-900/60 mb-2 font-semibold">Your Invitation Includes</p>
                  <div className="flex flex-col gap-2">
                    {guest.events?.map(id => {
                      const ev = EVENTS.find(e => e.id === id);
                      if (!ev) return null;
                      return (
                        <div key={id} className="border border-[#d4a017]/28 rounded-[3px] p-3 flex gap-3 items-center bg-white">
                          <div className="w-8 h-8 rounded-full bg-[#f5ebd0] flex items-center justify-center text-sm">{ev.icon}</div>
                          <div>
                            <div className="font-cormorant text-xs font-bold tracking-[0.1em] uppercase text-[#1a3a2a]">{ev.title}</div>
                            <div className="font-eb text-xs text-emerald-900/70">{ev.venue}</div>
                            <div className="font-eb text-[11px] text-emerald-900/50 mt-1">{ev.date} · {ev.time}</div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Attend Question */}
                <div className="border-t border-[#d4a017]/28 pt-5">
                  <p className="font-playfair italic text-[18px] text-[#0f2418] mb-4">Will you be joining us?</p>
                  <div className="flex gap-3 justify-center max-w-[320px] mx-auto">
                    <button
                      onClick={() => { setRsvp("yes"); showDetailsStep(); }}
                      className="flex-1 font-cormorant text-xs tracking-wider uppercase text-white bg-[#1a3a2a] p-3 rounded-[2px] hover:bg-[#0f2418] transition-all"
                    >
                      Attending
                    </button>
                    <button
                      onClick={() => { setRsvp("no"); showEmailOnlyStep(); }}
                      className="flex-1 font-cormorant text-xs tracking-wider uppercase text-[#1a3a2a] bg-white border border-emerald-950/20 p-3 rounded-[2px] hover:bg-emerald-900/5 transition-all"
                    >
                      Unable
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* STEP 3: Details Step */}
            {step === "details" && guest && (
              <div className="text-center">
                <p className="font-playfair italic text-xl text-[#0f2418] mb-5">
                  {rsvp === "yes" ? "A Few Quick Details" : "We Will Miss You"}
                </p>

                {rsvp === "yes" && (
                  <div className="mb-6">
                    {/* Headcount */}
                    <div className="mb-5">
                      <p className="font-cormorant text-[11px] tracking-wider uppercase text-emerald-900/60 mb-2">Number of guests attending</p>
                      <div className="flex items-center justify-center gap-4">
                        <button
                          onClick={() => setHeadcount(h => Math.max(1, h - 1))}
                          className="w-9 h-9 rounded-full border border-emerald-950/20 bg-white text-lg flex items-center justify-center text-[#1a3a2a]"
                        >
                          -
                        </button>
                        <span className="font-playfair text-2xl font-semibold min-w-[24px]">{headcount}</span>
                        <button
                          onClick={() => setHeadcount(h => Math.min(20, h + 1))}
                          className="w-9 h-9 rounded-full border border-emerald-950/20 bg-white text-lg flex items-center justify-center text-[#1a3a2a]"
                        >
                          +
                        </button>
                      </div>
                    </div>

                    {/* Event selections */}
                    <div className="text-left max-w-[440px] mx-auto mb-5">
                      <p className="font-cormorant text-[10px] tracking-wider uppercase text-emerald-900/60 mb-2">Select events you will attend</p>
                      <div className="flex flex-col gap-2">
                        {guest.events?.map(id => {
                          const ev = EVENTS.find(e => e.id === id);
                          if (!ev) return null;
                          const isOn = attendingEvents.has(id);
                          return (
                            <div
                              key={id}
                              onClick={() => toggleEventAttendance(id)}
                              className={`border rounded-[3px] p-3 flex items-center justify-between cursor-pointer transition-all ${
                                isOn ? "border-[#1a3a2a] bg-emerald-950/5" : "border-emerald-950/10 bg-white opacity-50"
                              }`}
                            >
                              <div className="flex items-center gap-3">
                                <div className="w-8 h-8 rounded-full bg-[#f5ebd0] flex items-center justify-center text-sm">{ev.icon}</div>
                                <div>
                                  <div className="font-cormorant text-xs font-bold tracking-wide uppercase text-[#1a3a2a]">{ev.title}</div>
                                  <div className="font-eb text-[11px] text-emerald-900/50 mt-0.5">{ev.date}</div>
                                </div>
                              </div>
                              <div className={`w-5 h-5 rounded-full border border-emerald-950/30 flex items-center justify-center text-xs ${isOn ? "bg-[#1a3a2a] text-white border-[#1a3a2a]" : "bg-white text-transparent"}`}>
                                ✓
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>

                    {/* Photo upload */}
                    <div className="border-t border-[#d4a017]/28 pt-4 mb-5">
                      <p className="font-playfair italic text-[16px] text-[#1a3a2a] mb-1">Share a photo! 📸</p>
                      <p className="font-eb italic text-xs text-emerald-900/50 leading-relaxed mb-3 max-w-[360px] mx-auto">
                        Optional: We'd love to see photos from your wedding! Share them with us for a little surprise! 😊❤️
                      </p>
                      <div className="border-2 border-dashed border-[#d4a017]/60 rounded-[4px] p-5 cursor-pointer bg-white relative hover:bg-[#faf3e0]/40 transition-all">
                        <input
                          type="file"
                          accept="image/*"
                          onChange={handlePhotoChange}
                          className="absolute inset-0 opacity-0 cursor-pointer w-full h-full"
                        />
                        <div className="text-2xl mb-1">🖼</div>
                        <div className="font-cormorant text-[10px] tracking-wider uppercase text-emerald-900/60">Tap to choose a photo</div>
                      </div>
                      {photoPreview && (
                        <div className="mt-3">
                          <img src={photoPreview} alt="Preview" className="max-h-[180px] mx-auto object-cover rounded-[2px] border border-emerald-950/20" />
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {/* Email Confirm */}
                <div className="border-t border-[#d4a017]/28 pt-4 mb-5">
                  <p className="font-playfair italic text-[16px] text-[#1a3a2a] mb-1">May we send you a confirmation? ✦</p>
                  <p className="font-eb italic text-xs text-emerald-900/50 leading-relaxed mb-3 max-w-[360px] mx-auto">
                    Please share your email address so we can send over your RSVP details and keep you updated on the celebrations.
                  </p>
                  <input
                    type="email"
                    placeholder="e.g. name@example.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full max-w-[280px] bg-white border border-emerald-950/30 rounded-[3px] p-2 text-center focus:border-[#d4a017] outline-none mx-auto block"
                  />
                </div>

                <button
                  onClick={() => handleSubmit(rsvp)}
                  disabled={submitting}
                  className="w-full font-cormorant text-xs tracking-wider uppercase text-[#faf3e0] bg-[#1a3a2a] border border-[#d4a017]/40 p-3 rounded-[2px] hover:bg-[#0f2418] transition-all disabled:opacity-40"
                >
                  {submitting ? "Saving response..." : "Confirm My RSVP"}
                </button>

                {submitError && (
                  <p className="font-eb italic text-xs text-red-700 mt-2">
                    {submitError}
                  </p>
                )}
              </div>
            )}

            {/* STEP 4: Confirmed State */}
            {step === "confirmed" && (
              <div className="text-center py-4">
                <div className="text-4xl mb-2">{rsvp === "yes" ? "🌸" : "✦"}</div>
                <h3 className="font-playfair italic text-2xl text-[#0f2418] mb-4">
                  {rsvp === "yes" ? "We are so thrilled!" : "Thank you for letting us know."}
                </h3>
                
                {rsvp === "yes" ? (
                  <p className="font-eb italic text-sm text-emerald-900/60 leading-relaxed mb-5 max-w-[360px] mx-auto">
                    We are excited to celebrate with you{headcount > 1 ? ` and your ${headcount - 1} guest${headcount > 2 ? "s" : ""}` : ""}. See you there!
                  </p>
                ) : (
                  <p className="font-eb italic text-sm text-emerald-900/60 leading-relaxed mb-5 max-w-[360px] mx-auto">
                    We will miss you dearly. Thank you for taking the time to respond.
                  </p>
                )}

                {rsvp === "yes" && attendingEvents.size > 0 && (
                  <div className="bg-[#d4a017]/5 border border-[#d4a017]/30 rounded-[2px] p-4 text-left max-w-[400px] mx-auto mb-5">
                    <p className="font-cormorant text-[10px] tracking-wider uppercase text-emerald-900/50 mb-2">Your Event Attendance</p>
                    <div className="flex flex-col gap-1">
                      {guest.events?.map(id => {
                        const ev = EVENTS.find(e => e.id === id);
                        if (!ev) return null;
                        const going = attendingEvents.has(id);
                        return (
                          <div key={id} className="flex items-center gap-2 text-[13px] font-eb">
                            <span className={going ? "text-emerald-900" : "text-emerald-900/30"}>{going ? "✓" : "✗"}</span>
                            <span className={going ? "text-emerald-950 font-medium" : "text-emerald-950/40"}>{ev.title}</span>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}

                {rsvp === "yes" && photoPreview && (
                  <div className="mb-5">
                    <p className="font-cormorant text-[10px] tracking-wider uppercase text-emerald-900/50 mb-1">Your Uploaded Photo</p>
                    <img src={photoPreview} alt="Uploaded" className="max-h-[180px] mx-auto object-cover rounded-[2px] border border-emerald-950/20" />
                  </div>
                )}

                <button
                  onClick={() => {
                    setStep("invite");
                  }}
                  className="font-cormorant text-[10px] tracking-wider uppercase text-[#1a3a2a] bg-white border border-emerald-950/20 py-2 px-4 rounded-[2px] hover:bg-emerald-900/5 transition-all mx-auto block"
                >
                  Change RSVP
                </button>
              </div>
            )}
          </div>

          <div style={{ height: "6px", background: "linear-gradient(90deg, transparent, rgba(212,160,23,0.5), transparent)" }} />
        </div>
      </div>
    </section>
  );
}
